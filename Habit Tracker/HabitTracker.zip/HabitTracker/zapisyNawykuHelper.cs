﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HabitTracker.Models;

namespace HabitTracker {
    public class zapisyNawykuHelper {
        MySql.Data.MySqlClient.MySqlConnection conn;
        public zapisyNawykuHelper() {
            string myConnectionString = "server=localhost;database=habittracker;uid=root;pwd=;";
            try {
                conn = new MySql.Data.MySqlClient.MySqlConnection();
                conn.ConnectionString = myConnectionString;
                conn.Open();
            } catch (MySql.Data.MySqlClient.MySqlException ex) {

            }
        }

        public long saveZapisNawyku(ZapisyNawyku zapisDoZapisu) {
            String sqlString = "INSERT INTO zapisy_nawyku (id_nawyku, id_miesiaca, dni_nawyku, rok) VALUES (" + zapisDoZapisu.id_nawyku + ", " + zapisDoZapisu.id_miesiaca + ", '0', " + zapisDoZapisu.rok + ")";
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            cmd.ExecuteNonQuery();
            long id = cmd.LastInsertedId;
            return id;
        }

        public List<ZapisyNawyku> GetZapisy() {
            List<ZapisyNawyku> us = new List<ZapisyNawyku>();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM zapisy_nawyku;";
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.HasRows) {
                while (mySqlReader.Read()) {
                    us.Add(new ZapisyNawyku {
                        id_zapisu = mySqlReader.GetInt32(0),
                        id_nawyku = mySqlReader.GetInt32(1),
                        id_miesiaca = mySqlReader.GetInt32(2),
                        dni_nawyku = mySqlReader.GetString(3),
                        rok = mySqlReader.GetInt32(4)
                    });
                }
                return us;
            } else return null;
        }

        public List<ZapisyNawyku> GetZapisyNawyku(long id) {
            List<ZapisyNawyku> us = new List<ZapisyNawyku>();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM zapisy_nawyku WHERE id_nawyku=" + id;
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.HasRows) {
                while (mySqlReader.Read()) {
                    us.Add(new ZapisyNawyku {
                        id_zapisu = mySqlReader.GetInt32(0),
                        id_nawyku = mySqlReader.GetInt32(1),
                        id_miesiaca = mySqlReader.GetInt32(2),
                        dni_nawyku = mySqlReader.GetString(3),
                        rok = mySqlReader.GetInt32(4)
                    });
                }
                return us;
            } else return null;
        }

        public bool UpdateZapis(long id, ZapisyNawyku zapisToUpdate) {
            Nawyk u = new Nawyk();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM zapisy_nawyku WHERE id_zapisu=" + id;
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.Read()) {
                string current = mySqlReader.GetString(3) + ", " + zapisToUpdate.dni_nawyku;
                mySqlReader.Close();
                sqlString = "UPDATE zapisy_nawyku SET dni_nawyku='" + current + "' WHERE id_zapisu=" + id;
                cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
                cmd.ExecuteNonQuery();
                return true;
            } else return false;
        }

        public bool RemoveDay(long id, ZapisyNawyku zapisToUpdate) {
            Nawyk u = new Nawyk();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM zapisy_nawyku WHERE id_zapisu=" + id;
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.Read()) {
                string current = mySqlReader.GetString(3).Replace(", " + zapisToUpdate.dni_nawyku, "");
                mySqlReader.Close();
                sqlString = "UPDATE zapisy_nawyku SET dni_nawyku='" + current + "' WHERE id_zapisu=" + id;
                cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
                cmd.ExecuteNonQuery();
                return true;
            } else return false;
        }
    }
}
