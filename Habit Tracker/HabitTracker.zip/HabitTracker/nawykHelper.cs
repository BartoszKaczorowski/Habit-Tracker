﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HabitTracker.Models;

namespace HabitTracker {
    public class nawykHelper {
        MySql.Data.MySqlClient.MySqlConnection conn;
        public nawykHelper() {
            string myConnectionString = "server=localhost;database=habittracker;uid=root;pwd=;";
            try {
                conn = new MySql.Data.MySqlClient.MySqlConnection();
                conn.ConnectionString = myConnectionString;
                conn.Open();
            } catch (MySql.Data.MySqlClient.MySqlException ex) {

            }
        }

        public long saveNawyk(Nawyk nawykToSave) {
            String sqlString = "INSERT INTO nawyki (id_uzytkownika, nazwa) VALUES (" + nawykToSave.id_uzytkownika + ", '" + nawykToSave.nazwa + "');";
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            cmd.ExecuteNonQuery();
            long id = cmd.LastInsertedId;
            return id;
        }

        public List<Nawyk> GetNawyki() {
            List<Nawyk> us = new List<Nawyk>();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM nawyki;";
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.HasRows) {
                while (mySqlReader.Read()) {
                    us.Add(new Nawyk {
                        id_nawyku = mySqlReader.GetInt32(0),
                        id_uzytkownika = mySqlReader.GetInt32(1),
                        nazwa = mySqlReader.GetString(2)
                    });
                }
                return us;
            } else return null;
        }

        public List<Nawyk> GetNawykiUzytkownika(long id) {
            List<Nawyk> us = new List<Nawyk>();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM nawyki WHERE id_uzytkownika=" + id;
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.HasRows) {
                while (mySqlReader.Read()) {
                    us.Add(new Nawyk {
                        id_nawyku = mySqlReader.GetInt32(0),
                        id_uzytkownika = mySqlReader.GetInt32(1),
                        nazwa = mySqlReader.GetString(2)
                    });
                }
                return us;
            } else return null;
        }

        public bool UpdateNawyk(long id, Nawyk NawykToUpdate) {
            Nawyk u = new Nawyk();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM nawyki WHERE id_nawyku=" + id;
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.Read()) {
                mySqlReader.Close();
                sqlString = "UPDATE nawyki SET nazwa='" + NawykToUpdate.nazwa + "' WHERE id_nawyku=" + id;
                cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
                cmd.ExecuteNonQuery();
                return true;
            } else return false;
        }

        public bool DeleteNawyk(long ID) {
            Nawyk u = new Nawyk();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM nawyki WHERE id_nawyku=" + ID;
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.Read()) {
                mySqlReader.Close();
                sqlString = "DELETE FROM nawyki WHERE id_nawyku=" + ID;
                cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
                cmd.ExecuteNonQuery();
                return true;
            } else return false;
        }
    }
}
