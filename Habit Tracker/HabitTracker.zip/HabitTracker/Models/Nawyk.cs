﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HabitTracker.Models {
    public class Nawyk {
        public long id_nawyku { get; set; }
        public long id_uzytkownika { get; set; }
        public String nazwa { get; set; }
    }
}
