﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HabitTracker.Models {
    public class Uzytkownik {
        public long ID { get; set; }
        public String LOGIN { get; set; }
        public String HASLO { get; set; }

    }
}
