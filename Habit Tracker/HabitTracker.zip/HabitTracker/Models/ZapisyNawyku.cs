﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HabitTracker.Models {
    public class ZapisyNawyku {
        public long id_zapisu { get; set; }
        public long id_nawyku { get; set; }
        public long id_miesiaca { get; set; }
        public string dni_nawyku { get; set; }
        public long rok { get; set; }
    }
}
