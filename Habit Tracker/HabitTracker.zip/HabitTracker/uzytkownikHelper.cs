﻿using HabitTracker.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HabitTracker {
    public class uzytkownikHelper {
        MySql.Data.MySqlClient.MySqlConnection conn;
        public uzytkownikHelper() {
            string myConnectionString = "server=localhost;database=habittracker;uid=root;pwd=;";
            try {
                conn = new MySql.Data.MySqlClient.MySqlConnection();
                conn.ConnectionString = myConnectionString;
                conn.Open();
            } catch (MySql.Data.MySqlClient.MySqlException ex) {

            }
        }

        public long saveUzytkownik(Uzytkownik uzytkownikDoZapisu) {
            String sqlString = "INSERT INTO uzytkownicy (LOGIN, HASLO) VALUES ('" + uzytkownikDoZapisu.LOGIN + "', '" + uzytkownikDoZapisu.HASLO + "');";
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            cmd.ExecuteNonQuery();
            long id = cmd.LastInsertedId;
            return id;
        }

        public Uzytkownik GetUzytkownik(string LOGIN, string HASLO) {
            Uzytkownik u = new Uzytkownik();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM uzytkownicy WHERE LOGIN='" + LOGIN + "' AND HASLO='" + HASLO + "'";
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.Read()) {
                u.ID = mySqlReader.GetInt32(0);
                u.LOGIN = mySqlReader.GetString(1);
                u.HASLO = mySqlReader.GetString(2);
                return u;
            }else return null;
        }

        public bool DeleteUzytkownik(long ID) {
            Uzytkownik u = new Uzytkownik();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM uzytkownicy WHERE ID=" + ID;
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.Read()) {
                mySqlReader.Close();
                sqlString = "DELETE FROM uzytkownicy WHERE ID=" + ID;
                cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
                cmd.ExecuteNonQuery();
                return true;
            } else return false;
        }

        public bool UpdateUzytkownik(long id, Uzytkownik uzytkownikDoUpdate) {
            Uzytkownik u = new Uzytkownik();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM uzytkownicy WHERE ID=" + id;
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.Read()) {
                mySqlReader.Close();
                sqlString = "UPDATE uzytkownicy SET HASLO='" + uzytkownikDoUpdate.HASLO + "' WHERE ID=" + id;
                cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
                cmd.ExecuteNonQuery();
                return true;
            } else return false;
        }

        public List<Uzytkownik> GetUzytkownicy() {
            List<Uzytkownik> us = new List<Uzytkownik>();
            MySql.Data.MySqlClient.MySqlDataReader mySqlReader = null;
            String sqlString = "SELECT * FROM uzytkownicy;";
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sqlString, conn);
            mySqlReader = cmd.ExecuteReader();
            if (mySqlReader.HasRows) {
                while (mySqlReader.Read()) {
                    us.Add(new Uzytkownik {
                        ID = mySqlReader.GetInt32(0),
                        LOGIN = mySqlReader.GetString(1),
                        HASLO = mySqlReader.GetString(2)
                    });
                }
                return us;
            } else return null;
        }
    }
}
