﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HabitTracker.Models;
using System.Net.Http;
using System.Net;

namespace HabitTracker.Controllers {
    [Route("api/[controller]")]
    [ApiController]
    public class uzytkownikController : ControllerBase {
        // GET: api/uzytkownik
        [HttpGet]
        public IEnumerable<Uzytkownik> Get() {
            uzytkownikHelper uh = new uzytkownikHelper();
            return uh.GetUzytkownicy();
        }

        // GET: api/uzytkownik/LOGIN/HASLO
        [HttpGet("{LOGIN}/{HASLO}", Name = "Get")]
        public Uzytkownik Get(string LOGIN, string HASLO) {
            uzytkownikHelper uh = new uzytkownikHelper();
            return uh.GetUzytkownik(LOGIN, HASLO);
        }

        // POST: api/uzytkownik
        [HttpPost]
        public HttpResponseMessage Post([FromBody] Uzytkownik value) {
            uzytkownikHelper uh = new uzytkownikHelper();
            long id = uh.saveUzytkownik(value);
            value.ID = id;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.Created);
            response.Headers.Location = new Uri("https://" + HttpContext.Request.Host.ToString() + "/api/uzytkownik/" + id);
            return response;
        }

        // PUT: api/uzytkownik/5
        [HttpPut("{id}")]
        public HttpResponseMessage Put(int id, [FromBody] Uzytkownik value) {
            uzytkownikHelper uh = new uzytkownikHelper();
            if (uh.UpdateUzytkownik(id, value)) {
                return new HttpResponseMessage(HttpStatusCode.NoContent);
            } else {
                return new HttpResponseMessage(HttpStatusCode.NotFound);
            }
        }

        // DELETE: api/uzytkownik/5
        [HttpDelete("{id}")]
        public HttpResponseMessage Delete(long id)  {
            uzytkownikHelper uh = new uzytkownikHelper();
            if (uh.DeleteUzytkownik(id)) {
                return new HttpResponseMessage(HttpStatusCode.NoContent);
            } else return new HttpResponseMessage(HttpStatusCode.NotFound);
        }
    }
}
