﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using HabitTracker.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HabitTracker.Controllers {
    [Route("api/[controller]")]
    [ApiController]
    public class nawykController : ControllerBase {
        // GET: api/nawyk
        [HttpGet]
        public IEnumerable<Nawyk> Get() {
            nawykHelper nh = new nawykHelper();
            return nh.GetNawyki();
        }

        // GET: api/nawyk/uzytkownik/5
        [HttpGet("uzytkownik/{id}", Name = "GetNawyk")]
        public IEnumerable<Nawyk> Get(int id) {
            nawykHelper nh = new nawykHelper();
            return nh.GetNawykiUzytkownika(id);
        }

        // POST: api/nawyk
        [HttpPost]
        public HttpResponseMessage Post([FromBody] Nawyk value) {
            nawykHelper nh = new nawykHelper();
            long id = nh.saveNawyk(value);
            value.id_nawyku = id;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.Created);
            response.Headers.Location = new Uri("https://" + HttpContext.Request.Host.ToString() + "/api/nawyk/uzytkownik/" + value.id_uzytkownika);
            return response;
        }

        // PUT: api/nawyk/5
        [HttpPut("{id}")]
        public HttpResponseMessage Put(int id, [FromBody] Nawyk value) {
            nawykHelper nh = new nawykHelper();
            if (nh.UpdateNawyk(id, value)) {
                return new HttpResponseMessage(HttpStatusCode.NoContent);
            } else {
                return new HttpResponseMessage(HttpStatusCode.NotFound);
            }
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public HttpResponseMessage Delete(int id) {
            nawykHelper nh = new nawykHelper();
            if (nh.DeleteNawyk(id)) {
                return new HttpResponseMessage(HttpStatusCode.NoContent);
            } else return new HttpResponseMessage(HttpStatusCode.NotFound);
        }
    }
}
