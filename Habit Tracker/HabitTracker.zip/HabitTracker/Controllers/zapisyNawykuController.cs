﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HabitTracker.Models;
using System.Net.Http;
using System.Net;

namespace HabitTracker.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class zapisyNawykuController : ControllerBase
    {
        // GET: api/zapisyNawyku
        [HttpGet]
        public IEnumerable<ZapisyNawyku> Get() {
            zapisyNawykuHelper znh = new zapisyNawykuHelper();
            return znh.GetZapisy();
        }

        // GET: api/zapisyNawyku/nawyki/5
        [HttpGet("nawyki/{id}", Name = "GetZapis")]
        public IEnumerable<ZapisyNawyku> Get(int id) {
            zapisyNawykuHelper znh = new zapisyNawykuHelper();
            return znh.GetZapisyNawyku(id);
        }

        // POST: api/zapisyNawyku
        [HttpPost]
        public HttpResponseMessage Post([FromBody] ZapisyNawyku value) {
            zapisyNawykuHelper znh = new zapisyNawykuHelper();
            long id = znh.saveZapisNawyku(value);
            value.id_zapisu = id;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.Created);
            response.Headers.Location = new Uri("https://" + HttpContext.Request.Host.ToString() + "/api/zapisyNawyku/nawyki/" + value.id_nawyku);
            return response;
        }

        // PUT: api/zapisyNawyku/5
        [HttpPut("{id}")]
        public HttpResponseMessage Put(int id, [FromBody] ZapisyNawyku value) {
            zapisyNawykuHelper znh = new zapisyNawykuHelper();
            if (znh.UpdateZapis(id, value)) {
                return new HttpResponseMessage(HttpStatusCode.NoContent);
            } else {
                return new HttpResponseMessage(HttpStatusCode.NotFound);
            }
        }

        // DELETE: api/zapisyNawyku/5
        [HttpDelete("{id}")]
        public HttpResponseMessage Delete(int id, [FromBody] ZapisyNawyku value) {
            zapisyNawykuHelper znh = new zapisyNawykuHelper();
            if (znh.RemoveDay(id, value)) {
                return new HttpResponseMessage(HttpStatusCode.NoContent);
            } else return new HttpResponseMessage(HttpStatusCode.NotFound);
        }
    }
}
